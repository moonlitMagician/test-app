import { Text, View } from "react-native";
import styles from './styles.js';
export default function Index() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>the wolf howls and the hawk tuahs...</Text>
    </View>
  );
}
  